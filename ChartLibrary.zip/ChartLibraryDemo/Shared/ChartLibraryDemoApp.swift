//
//  ChartLibraryDemoApp.swift
//  Shared
//
//  Created by Sorin Dolha on 26.08.2021.
//

import SwiftUI

@main
struct ChartLibraryDemoApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView().frame(width: 400, height: 250)
        }
    }
}
