    import XCTest
    @testable import ChartLibrary

    final class ChartLibraryTests: XCTestCase {
    }
